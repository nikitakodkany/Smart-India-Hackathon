package com.example.retrofitpostrawjson;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.retrofitpostrawjson.webservice.IRetrofit;
import com.example.retrofitpostrawjson.webservice.ServiceGenerator;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onPostClicked(View view){
        //creating the json object to send
        JsonObject jsonObject = new JsonObject();
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("user","Bing");
        JsonArray citiesArray = new JsonArray();
        citiesArray.add("New York");
        citiesArray.add("Tulsa");
        jsonObject.add("cities", citiesArray);

        // Using the Retrofit
        IRetrofit jsonPostService = ServiceGenerator.createService(IRetrofit.class, "http://yourwebserviceapi/");
        Call<JsonObject> call = jsonPostService.postRawJSON(jsonObject);
        call.enqueue(new Callback<JsonObject>() {

            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                try{
                    Log.e("response-success", response.body().toString());
                }catch (Exception e){
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("response-failure", call.toString());
            }
        });
    }
}
